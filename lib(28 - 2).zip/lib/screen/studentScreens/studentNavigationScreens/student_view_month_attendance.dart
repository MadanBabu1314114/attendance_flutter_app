import 'package:flutter/material.dart';

class StudentviewMonthAttendance extends StatelessWidget {
  const StudentviewMonthAttendance({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: Text("Stduent View Month Attendance"),
      ),
      body: Center(
        child: Text("StudentView Month Attendance"),
      ),
    );
  }
}
