import 'package:flutter/material.dart';

class BottomIcon extends StatelessWidget {
  const BottomIcon({super.key});
  
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw UnimplementedError();
  }
  
  
  
}