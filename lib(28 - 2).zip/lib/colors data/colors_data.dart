import 'package:flutter/material.dart';

Color lightNavigationbar = Color.fromARGB(234, 167, 217, 240);
Color textColor =Color.fromARGB(234, 47, 143, 187);
Color CardColor = Color.fromARGB(255, 167, 138, 190).withOpacity(0.5);
Color textfieldColor =  Color.fromARGB(255, 194, 163, 235);
Color buttonColor = Color.fromARGB(234, 13, 127, 180);